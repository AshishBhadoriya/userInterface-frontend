"use client"
import { Box, Grid } from "@mui/material";
import SubCategories from "../components/subcategorycomponents/SubCategories";
import Scroll from "../components/subcategorycomponents/Slider";
import Slider from "../components/subcategorycomponents/Slider";
import Packages from "../components/subcategorycomponents/Packages";
import Promise from "../components/subcategorycomponents/Promise";
import Cart from "../components/subcategorycomponents/Cart";
import {useMediaQuery} from "@mui/material";
import { useState } from "react";
import Footer from "../components/footercomponents/Footer";
import Header from "../components/headercomponents/Header";


export default function subcategory(){
    const [cartItem,setCartItem]=useState([])
    const halfScreen=useMediaQuery("(max-width:900px)")
    return(<div>
        <Header/>
    <div style={{width:'100vw',maxWidth:'1350px',height:'100%',margin:'auto',display:'flex',gap:'30px',padding:'20px',marginTop:'90px'}} >
        <div style={{width:'320px',height:'100%',display:'flex',flexDirection:'column'}} >
          <SubCategories/>
          <div style={{width:'100%',height:'auto',display: halfScreen ? "" : "none"}} >
            <Cart cartItem={cartItem} setCartItem={setCartItem}/>
            <Promise/>
          </div>
        </div>
        <div style={{width:'70%',height:'100%',display:'flex',flexDirection:'column',gap:'30px'}} >
            <div style={{width:'100%',height:'auto',display: halfScreen ? "" : ""}} >
               <Slider/>
            </div>
            <div style={{width:'100%',height:'100%',display:'flex',height:'auto',position:'sticky',top:'0px'}} >
                <div style={{minWidth:'400px',width:'100%',height:'auto',border:'1px solid #c4c3c3',borderTopLeftRadius:'10px'}} >
                   <Packages cartItem={cartItem} setCartItem={setCartItem}/>
                </div>
                <div style={{width:'60%',height:'100',borderTop:'1px solid #c4c3c3',padding:'20px',position:'sticky',top:'10px',display: halfScreen ? "none" : ""}} >
                   <Promise/>
                   <Cart cartItem={cartItem} setCartItem={setCartItem}/>
                </div>

            </div>

        </div>
    </div>
    <Footer/>
    </div>)
}